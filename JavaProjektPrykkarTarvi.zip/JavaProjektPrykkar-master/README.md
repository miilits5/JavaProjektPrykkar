# JavaProjektPrykkar
Õpime progema javas ja
teeme programmi, mis aitab prügi sorteerida
